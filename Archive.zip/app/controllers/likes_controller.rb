class LikesController < ApplicationController
  	def index

  	end
  	